const colors = {
  accent: "#fd79a8",
  textColor: "#dfe6e9",
  backgroundColor:"#1e272e"
}

export default colors;